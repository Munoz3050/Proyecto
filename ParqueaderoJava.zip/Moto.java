public class Moto {
    private String placa;
    private String marca;
    private String color;
    private int cilindraje;

    public Moto(String placa, String marca, String color, int cilindraje) {
        this.placa = placa;
        this.marca = marca;
        this.color = color;
        this.cilindraje = cilindraje;
    }

    public void estacionar() {
        System.out.println("Moto estacionada");
    }

    public void retirar() {
        System.out.println("Moto retirada");
    }
}