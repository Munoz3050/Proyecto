public class Gasto {
    private String tipo;
    private float monto;
    private String fecha = "2024-05-07";

    public Gasto(String tipo, float monto) {
        this.tipo = tipo;
        this.monto = monto;
    }

    public void mostrarDetalle() {
        System.out.println("Gasto tipo: " + tipo + ", monto: " + monto);
    }
}