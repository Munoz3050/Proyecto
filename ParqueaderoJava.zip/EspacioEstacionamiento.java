public class EspacioEstacionamiento {
    private int numero;
    private boolean ocupado;

    public EspacioEstacionamiento(int numero) {
        this.numero = numero;
        this.ocupado = false;
    }

    public void asignarMoto(Moto moto) {
        this.ocupado = true;
        System.out.println("Moto asignada al espacio " + numero);
    }

    public void liberarEspacio() {
        this.ocupado = false;
        System.out.println("Espacio " + numero + " liberado");
    }

    public void espacioMensualidad() {
        System.out.println("Espacio reservado para mensualidad");
    }
}