public class Administrador extends Persona {
    public Administrador(String nombre, String ID) {
        super(nombre, ID);
    }

    public Gasto registrarGasto(String tipo, float monto) {
        return new Gasto(tipo, monto);
    }
}