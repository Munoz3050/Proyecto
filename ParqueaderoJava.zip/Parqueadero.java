public class Parqueadero {
    private String nombre;
    private String direccion;
    private int capacidad;

    public Parqueadero(String nombre, String direccion, int capacidad) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.capacidad = capacidad;
    }
}