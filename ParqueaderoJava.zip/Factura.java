public class Factura {
    private int numero;
    private Cliente cliente;
    private String fecha = "2024-05-07";
    private String horaEntrada = "07:00";
    private String horaSalida = "17:00";
    private float costo;

    public Factura(int numero, Cliente cliente, float costo) {
        this.numero = numero;
        this.cliente = cliente;
        this.costo = costo;
    }

    public void mostrarDetalle() {
        System.out.println("Factura No: " + numero + ", Cliente: " + cliente);
    }

    public float calcularCosto() {
        return costo;
    }
}