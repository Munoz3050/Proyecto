public class Main {
    public static void main(String[] args) {
        Cliente cliente = new Cliente("Juan Perez", "123456789", "3001234567");
        Moto moto = new Moto("ABC123", "Yamaha", "Rojo", 150);
        Empleado empleado = new Empleado("Carlos", "EMP001", "Mañana");
        Administrador admin = new Administrador("Laura", "ADM001");

        Factura factura = empleado.generarFactura(cliente, 5000);
        factura.mostrarDetalle();

        Gasto gasto = admin.registrarGasto("Luz", 20000);
        gasto.mostrarDetalle();

        EspacioEstacionamiento espacio = new EspacioEstacionamiento(1);
        espacio.asignarMoto(moto);
        espacio.liberarEspacio();

        Mensualidad mensualidad = new Mensualidad(cliente, moto, "2024-05-01", "2024-05-31", 100000);
        mensualidad.pagarMensualidad();

        Parqueadero parqueadero = new Parqueadero("Mi Parqueadero", "Cra 1 #2-34", 50);
    }
}