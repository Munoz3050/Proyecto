public class Persona {
    protected String nombre;
    protected String ID;

    public Persona(String nombre, String ID) {
        this.nombre = nombre;
        this.ID = ID;
    }
}