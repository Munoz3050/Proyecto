public class Mensualidad {
    private Cliente cliente;
    private Moto moto;
    private String fechaInicio;
    private String fechaFin;
    private float costo;

    public Mensualidad(Cliente cliente, Moto moto, String fechaInicio, String fechaFin, float costo) {
        this.cliente = cliente;
        this.moto = moto;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.costo = costo;
    }

    public void pagarMensualidad() {
        System.out.println("Mensualidad pagada");
    }

    public void espacioMensualidad() {
        System.out.println("Espacio asignado por mensualidad");
    }
}