public class Empleado extends Persona {
    private String turno;

    public Empleado(String nombre, String ID, String turno) {
        super(nombre, ID);
        this.turno = turno;
    }

    public void registrarIngreso() {
        System.out.println("Ingreso registrado.");
    }

    public void registrarSalida() {
        System.out.println("Salida registrada.");
    }

    public Factura generarFactura(Cliente cliente, float monto) {
        return new Factura(1, cliente, monto);
    }
}